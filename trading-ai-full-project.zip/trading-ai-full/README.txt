TRADING AI ANALYZER — WINDOWS LOCAL VERSION

Folder structure:
- frontend/index.html: website interface
- backend/app.py: Python API backend
- backend/requirements.txt: Python packages
- run.bat: starts backend and asks for API key

Requirements:
- Windows
- Python 3.12 or newer installed and available as `python`
- Internet connection
- An OpenAI API key with API billing/access enabled

START:
1. Extract the ZIP file.
2. Open the extracted trading-ai-full folder.
3. Double-click run.bat. If Windows blocks it, open PowerShell in this folder and run:
   .\run.bat
4. Enter your OpenAI API key in the terminal when prompted. Do not share it.
5. Keep the terminal open.
6. Open frontend\index.html in a browser (double-click it or run `start .\frontend\index.html` from the project root).
7. Upload a chart screenshot and click AI bilan tahlil qilish.

If website says backend connection failed:
- Make sure run.bat terminal is still open.
- Open http://127.0.0.1:8000 in browser; it should show a status JSON.
- Check the error printed in the backend terminal.
- Never paste your API key into chat or screenshots.

Note:
This is a local development starter, not a production-secure public deployment. Before hosting publicly, restrict CORS, add authentication/rate limits, and protect uploaded files and secrets. Trading analysis can be wrong and is not financial advice.
