@echo off
setlocal
cd /d "%~dp0"
echo ===========================================
echo Trading AI Analyzer - Backend launcher
echo ===========================================
if not exist ".venv\Scripts\python.exe" (
  echo Creating Python virtual environment...
  python -m venv .venv
  if errorlevel 1 (
    echo ERROR: Python was not found. Install Python 3.12+ and enable Add Python to PATH.
    pause
    exit /b 1
  )
)
echo Installing/updating required packages...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r "backend\requirements.txt"
if errorlevel 1 (
  echo ERROR: Package installation failed. Check internet and Python installation.
  pause
  exit /b 1
)
if "%OPENAI_API_KEY%"=="" (
  echo.
  echo Enter your OpenAI API key. It will be kept only in this terminal session.
  set /p OPENAI_API_KEY=API key: 
)
if "%OPENAI_API_KEY%"=="" (
  echo ERROR: No API key entered.
  pause
  exit /b 1
)
set OPENAI_API_KEY=%OPENAI_API_KEY%
echo.
echo Backend starting at http://127.0.0.1:8000
echo Keep this window open while using the website.
".venv\Scripts\python.exe" -m uvicorn backend.app:app --host 127.0.0.1 --port 8000
pause
