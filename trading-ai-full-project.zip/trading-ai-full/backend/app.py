import os
import base64
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from openai import OpenAI

app = FastAPI(title="Trading AI Analyzer API")

# Local development only. Restrict origins before deploying publicly.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def health():
    return {"status": "ok", "message": "Trading AI backend ishlayapti"}

@app.post("/analyze")
async def analyze(
    image: UploadFile = File(...),
    asset: str = Form("BTCUSDT"),
    timeframe: str = Form("5m"),
):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise HTTPException(status_code=500, detail="OPENAI_API_KEY sozlanmagan. Terminalda API kalitini kiriting.")

    allowed_types = {"image/png", "image/jpeg", "image/webp"}
    if image.content_type not in allowed_types:
        raise HTTPException(status_code=400, detail="PNG, JPG yoki WEBP rasm yuklang.")

    image_bytes = await image.read()
    if not image_bytes:
        raise HTTPException(status_code=400, detail="Yuklangan rasm bo'sh.")
    if len(image_bytes) > 10 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Rasm hajmi 10 MB dan oshmasligi kerak.")

    encoded = base64.b64encode(image_bytes).decode("utf-8")
    image_url = f"data:{image.content_type};base64,{encoded}"

    prompt = f"""
Sen ehtiyotkor trading grafik tahlil yordamchisisan.
Aktiv: {asset}
Timeframe: {timeframe}

Grafikni shu tartibda tahlil qil va O'ZBEK TILIDA javob ber:
1. Market Structure: trend, ko'rinadigan HH/HL/LH/LL.
2. Liquidity Zones: ko'rinadigan oldingi swing high/low, equal highs/lows.
3. Liquidity Sweep: sweep aniq ko'rinadimi yoki yo'qmi.
4. BOS/CHoCH: faqat rasmda dalil bo'lsa ayt.
5. Trade plan: entry, stop loss, take profit faqat narxlar o'qilsa; aks holda NO TRADE.

Qoidalar:
- Rasmda o'qib bo'lmaydigan narxlarni to'qib chiqarmagin.
- Kuzatilgan dalillarni taxmindan ajrat.
- Dalil yetarli bo'lmasa NO TRADE deb yoz.
- Bu moliyaviy maslahat emas va natija kafolatlanmaydi.
"""

    try:
        client = OpenAI(api_key=api_key)
        response = client.responses.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
            input=[{
                "role": "user",
                "content": [
                    {"type": "input_text", "text": prompt},
                    {"type": "input_image", "image_url": image_url},
                ],
            }],
        )
        return {"analysis": response.output_text}
    except Exception as exc:
        # Detailed error is printed in the backend terminal, not exposed to the browser.
        print(f"OpenAI request failed: {type(exc).__name__}: {exc}")
        raise HTTPException(
            status_code=502,
            detail="OpenAI so'rovi bajarilmadi. Backend terminalidagi xatoni tekshiring (API kalitini oshkor qilmang).",
        )
